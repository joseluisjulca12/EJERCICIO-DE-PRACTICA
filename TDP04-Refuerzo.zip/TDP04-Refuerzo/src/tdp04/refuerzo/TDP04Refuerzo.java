package tdp04.refuerzo;

public class TDP04Refuerzo {

    public static void main(String[] args) {
        System.out.println("BIENVENIDO AL TALLER DE REFUERZO");
        new Ejercicios().ejercicio3();
    }
    
}
